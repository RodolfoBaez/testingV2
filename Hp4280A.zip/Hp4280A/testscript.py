from visacon import VisaCon
from controller import controller

###test calls
conn = VisaCon()
ctrl = controller(conn, 5.0, (0.0), 5.0, 0.50, 0.3, 0.3)
#ctrl.clear()
#ctrl.single_config()
#ctrl.set_cgtfunc() ### Set the CGT function
#ctrl.set_ctfunc()
#ctrl.default_CT()
#ctrl.set_double()
#ctrl.sweep_measure() ### Perform a sweep measurement
#ctrl.pulse_sweep(5, 5.0)
#ctrl.pulse_sweep()

#ctrl.single_config()

ctrl.default_CT()
ctrl.set_td(2) # Set the delay time to 2 seconds
ctrl.set_th(2) # Set the hold time to 2 seconds
ctrl.set_Measure_pulse(1) # Set the measure pulse which is a voltage value
ctrl.set_Pulse(6) # Set the pulse voltage to a voltage value
ctrl.set_NOFREAD(20) # Set the number of reads to 10 (this is the number of times the pulse will be measured)

ctrl.sweep_measure() #starts the measurement
"""
def pulse_algorithm_test(v_start=0.0, v_step=0.5, v_end=5.0):
    current_end = v_step
    actual_end = v_end
    while current_end <= actual_end:
        print("self.set_end", current_end)
        v = v_start
        print(v)
        v += v_step
        print("Pulse complete\n")  # Marks the end of one pulse cycle
        current_end += v_step
        print('current_end', current_end)
        print('actual_end', actual_end)

pulse_algorithm_test()
"""
